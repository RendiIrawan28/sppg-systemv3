<?php

namespace App\Livewire\V3\PreparationOutputs;

use App\Enums\PortioningSessionState;
use App\Enums\ProcessingBatchState;
use App\Enums\UserRole;
use App\Livewire\V3\Concerns\InteractsWithV3Shell;
use App\Livewire\V3\Concerns\FiltersByWorkDate;
use App\Models\PortioningSession;
use App\Models\PreparationOutput;
use App\Models\PreparationSession;
use App\Models\PreparationSessionItem;
use App\Models\ProcessingBatch;
use App\Services\PreparationOutputService;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class Index extends Component
{
    use InteractsWithV3Shell;
    use FiltersByWorkDate;
    use WithFileUploads;

    public ?int $sessionId = null;

    public ?int $itemId = null;

    public string $outputName = '';

    public string $quantity = '';

    public string $unitSnapshot = '';

    public string $targetDivision = 'processing';

    public string $storageLocation = '';

    public string $expiresAt = '';

    public string $outputNotes = '';

    public mixed $outputPhoto = null;

    public array $requestQuantities = [];

    public array $requestDivisions = [];

    public array $targetDivisions = [];

    public array $processingBatchIds = [];

    public array $portioningSessionIds = [];

    public array $requestNotes = [];

    public function mount(): void
    {
        $this->currentUnit();
        abort_unless(
            $this->allowed('preparation.view')
            || $this->allowed('processing.view')
            || $this->allowed('portioning.view'),
            403,
        );
    }

    public function updatedSessionId(): void
    {
        $this->itemId = null;
        $this->unitSnapshot = '';
    }

    public function updatedItemId(): void
    {
        if (! $this->itemId) {
            return;
        }

        $item = PreparationSessionItem::query()->find($this->itemId);
        $this->unitSnapshot = (string) ($item?->unit_snapshot ?: 'kg');
        $this->outputName = (string) ($item?->ingredient_name_snapshot ?: '');
    }

    public function createOutput(PreparationOutputService $service): void
    {
        abort_unless($this->allowed('preparation.update'), 403);

        $data = $this->validate([
            'sessionId' => ['required', 'integer'],
            'itemId' => ['required', 'integer'],
            'outputName' => ['required', 'string', 'max:255'],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'unitSnapshot' => ['required', 'string', 'max:80'],
            'targetDivision' => ['required', 'in:processing,portioning,both'],
            'storageLocation' => ['nullable', 'string', 'max:255'],
            'expiresAt' => ['nullable', 'date'],
            'outputNotes' => ['nullable', 'string', 'max:2000'],
            'outputPhoto' => ['nullable', 'image', 'max:5120'],
        ]);

        $unit = $this->currentUnit();
        $session = PreparationSession::query()
            ->where('sppg_unit_id', $unit->getKey())
            ->findOrFail($data['sessionId']);
        $item = $session->items()->findOrFail($data['itemId']);
        $photoPath = $this->outputPhoto
            ? $this->outputPhoto->store('preparation/outputs/'.today()->format('Y/m/d'), 'public')
            : null;

        try {
            $service->store($session, $item, auth()->user(), [
                'output_name' => $data['outputName'],
                'quantity' => $data['quantity'],
                'unit_snapshot' => $data['unitSnapshot'],
                'target_division' => $data['targetDivision'],
                'storage_location' => $data['storageLocation'],
                'expires_at' => $data['expiresAt'] ?: null,
                'photo_path' => $photoPath,
                'notes' => $data['outputNotes'],
            ]);
        } catch (\Throwable $exception) {
            if ($photoPath) {
                Storage::disk('public')->delete($photoPath);
            }
            throw $exception;
        }

        $this->reset([
            'itemId', 'outputName', 'quantity', 'unitSnapshot', 'storageLocation',
            'expiresAt', 'outputNotes', 'outputPhoto',
        ]);
        $this->targetDivision = 'processing';
        session()->flash('v3.status', 'Hasil Persiapan berhasil disimpan.');
    }

    public function requestWithdrawal(int $outputId, PreparationOutputService $service): void
    {
        $output = $this->output($outputId);
        $division = $this->resolveRequestDivision($outputId, $output);

        $service->requestWithdrawal($output, auth()->user(), [
            'destination_division' => $division,
            'requested_quantity' => $this->requestQuantities[$outputId] ?? null,
            'processing_batch_id' => $this->processingBatchIds[$outputId] ?? null,
            'portioning_session_id' => $this->portioningSessionIds[$outputId] ?? null,
            'notes' => $this->requestNotes[$outputId] ?? null,
        ]);

        unset(
            $this->requestQuantities[$outputId],
            $this->requestDivisions[$outputId],
            $this->processingBatchIds[$outputId],
            $this->portioningSessionIds[$outputId],
            $this->requestNotes[$outputId],
        );
        session()->flash('v3.status', 'Hasil Persiapan berhasil diambil dan langsung tersedia di divisi tujuan.');
    }

    public function changeTargetDivision(int $outputId, PreparationOutputService $service): void
    {
        abort_unless($this->canChangeTargetDivision(), 403);

        $output = $this->output($outputId);
        $this->targetDivisions[$outputId] ??= $output->target_division;
        $this->validate([
            "targetDivisions.{$outputId}" => ['required', 'in:processing,portioning,both'],
        ], [], [
            "targetDivisions.{$outputId}" => 'tujuan penggunaan',
        ]);

        $service->changeTargetDivision(
            $output,
            auth()->user(),
            $this->targetDivisions[$outputId],
        );

        unset($this->targetDivisions[$outputId]);
        session()->flash('v3.status', 'Tujuan penggunaan hasil Persiapan berhasil diubah.');
    }

    public function render()
    {
        $unit = $this->currentUnit();
        $sessions = PreparationSession::query()
            ->with('items')
            ->where('sppg_unit_id', $unit->getKey())
            ->whereIn('state', ['in_progress', 'completed'])
            ->whereDate('preparation_date', $this->selectedWorkDate())
            ->latest('preparation_date')
            ->limit(30)
            ->get();

        $selectedItems = $this->sessionId
            ? $sessions->firstWhere('id', $this->sessionId)?->items ?? collect()
            : collect();

        $outputs = PreparationOutput::query()
            ->with([
                'session', 'sourceItem',
                'withdrawals.taker',
                'withdrawals.processingBatch', 'withdrawals.portioningSession',
            ])
            ->where('sppg_unit_id', $unit->getKey())
            ->where(function ($query): void {
                $query->whereDate('stored_at', $this->selectedWorkDate())
                    ->orWhereIn('state', [PreparationOutput::AVAILABLE, PreparationOutput::PARTIALLY_TAKEN]);
            })
            ->latest('stored_at')
            ->latest('id')
            ->get();

        $processingBatches = ProcessingBatch::query()
            ->where('sppg_unit_id', $unit->getKey())
            ->where('state', ProcessingBatchState::InProgress->value)
            ->whereDate('production_date', $this->selectedWorkDate())
            ->latest('production_date')
            ->limit(50)
            ->get();
        $portioningSessions = PortioningSession::query()
            ->where('sppg_unit_id', $unit->getKey())
            ->where('state', PortioningSessionState::InProgress->value)
            ->whereDate('portioning_date', $this->selectedWorkDate())
            ->latest('portioning_date')
            ->limit(50)
            ->get();

        return view('livewire.v3.preparation-outputs.index', [
            ...$this->shellData($unit),
            'sessions' => $sessions,
            'selectedItems' => $selectedItems,
            'outputs' => $outputs,
            'processingBatches' => $processingBatches,
            'portioningSessions' => $portioningSessions,
            'canCreate' => $this->allowed('preparation.update'),
            'canTakeProcessing' => $this->allowed('processing.update'),
            'canTakePortioning' => $this->allowed('portioning.update'),
            'canChangeTarget' => $this->canChangeTargetDivision(),
        ])->layout('layouts.v3', ['title' => 'Penyimpanan Hasil Persiapan']);
    }

    private function output(int $id): PreparationOutput
    {
        return PreparationOutput::query()
            ->where('sppg_unit_id', $this->currentUnit()->getKey())
            ->findOrFail($id);
    }

    private function resolveRequestDivision(int $outputId, PreparationOutput $output): string
    {
        $selected = (string) ($this->requestDivisions[$outputId] ?? '');
        if ($selected !== '') {
            return $selected;
        }

        if ($this->allowed('processing.update') && $output->isAvailableFor('processing')) {
            return 'processing';
        }

        if ($this->allowed('portioning.update') && $output->isAvailableFor('portioning')) {
            return 'portioning';
        }

        abort(403);
    }

    private function canChangeTargetDivision(): bool
    {
        $user = auth()->user();

        return $user->is_super_admin
            || $user->hasRole(UserRole::KepalaDivisiPersiapan->value);
    }
}
