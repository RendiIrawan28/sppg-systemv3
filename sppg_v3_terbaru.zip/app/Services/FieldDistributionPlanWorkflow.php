<?php

namespace App\Services;

use App\Enums\DistributionRunState;
use App\Enums\FieldDistributionPlanStatus;
use App\Models\FieldDistributionPlan;
use App\Models\User;
use App\Support\V3\SystemUnit;
use DomainException;
use Illuminate\Support\Facades\DB;

class FieldDistributionPlanWorkflow
{
    public function submissionIssues(FieldDistributionPlan $plan): array
    {
        $plan->recalculateTotals();
        $plan->load('destinations.recipientGroups');
        $issues = [];

        if ($plan->distribution_date) {
            $holiday = app(MenuServiceCalendarService::class)->holidayFor(
                (int) $plan->sppg_unit_id,
                $plan->distribution_date,
            );
            if ($holiday) {
                $issues[] = $plan->distribution_date->format('d-m-Y')." merupakan hari libur pelayanan: {$holiday->name}. Rencana Distribusi tidak dapat diaktifkan.";
            }
        }

        if (blank($plan->service_date) || blank($plan->production_date)) {
            $issues[] = 'Tanggal layanan dan tanggal produksi dari siklus menu belum valid.';
        }

        if ($plan->destinations->isEmpty()) {
            $issues[] = 'Minimal satu sekolah atau Posyandu wajib ditambahkan.';
        }

        foreach ($plan->destinations as $index => $destination) {
            $label = $destination->destination_name_snapshot ?: 'Tujuan '.($index + 1);

            if ($destination->recipientGroups->isEmpty()) {
                $issues[] = "{$label}: rincian kelompok penerima belum diisi.";
            }

            $isNotServed = (int) $destination->total_portions === 0;

            foreach ($destination->recipientGroups as $group) {
                $groupLabel = $group->beneficiary_category_name_snapshot ?: 'Kelompok penerima';

                // Nilai 0 sah, misalnya kelompok tidak hadir atau sekolah tidak menerima pelayanan.
                if ((int) $group->confirmed_beneficiaries < 0) {
                    $issues[] = "{$label} - {$groupLabel}: jumlah aktual tidak boleh negatif.";
                }

                if (! in_array($group->portion_size, ['small', 'large'], true)) {
                    $issues[] = "{$label} - {$groupLabel}: kategori porsi belum valid.";
                }
            }

            if ((int) $destination->confirmed_beneficiaries < 0) {
                $issues[] = "{$label}: jumlah penerima terkonfirmasi tidak boleh negatif.";
            }

            if ((int) $destination->total_portions < 0) {
                $issues[] = "{$label}: jumlah porsi tidak boleh negatif.";
            }

            if ((int) $destination->total_portions !== (int) $destination->confirmed_beneficiaries) {
                $issues[] = "{$label}: total porsi harus sama dengan penerima terkonfirmasi.";
            }

            // Tujuan dengan total 0 dianggap tidak menerima pelayanan pada tanggal tersebut.
            // Rute dan urutan hanya wajib untuk tujuan yang benar-benar dilayani.
            if (! $isNotServed && blank($destination->route_name)) {
                $issues[] = "{$label}: rute distribusi belum diisi.";
            }

            if (! in_array($destination->confirmation_status, ['confirmed', 'changed'], true)) {
                $issues[] = "{$label}: konfirmasi penerima belum selesai.";
            }

            if ($destination->confirmation_status === 'changed' && blank($destination->change_reason)) {
                $issues[] = $isNotServed
                    ? "{$label}: alasan tidak menerima pelayanan wajib diisi."
                    : "{$label}: alasan perubahan jumlah penerima wajib diisi.";
            }

            if (in_array($destination->confirmation_status, ['confirmed', 'changed'], true)
                && ! $destination->confirmed_at) {
                $issues[] = "{$label}: waktu konfirmasi belum diisi.";
            }
        }

        $duplicateSequences = $plan->destinations
            ->filter(fn ($destination): bool => (int) $destination->total_portions > 0)
            ->groupBy(fn ($destination): string => trim((string) $destination->route_name))
            ->flatMap(function ($destinations, string $routeName) {
                return $destinations
                    ->groupBy('sequence_order')
                    ->filter(fn ($items): bool => $items->count() > 1)
                    ->keys()
                    ->map(fn ($sequence): string => "{$routeName} urutan {$sequence}");
            });

        if ($duplicateSequences->isNotEmpty()) {
            $issues[] = 'Urutan tujuan dalam satu rute tidak boleh sama: '.$duplicateSequences->implode(', ').'.';
        }

        if ($plan->planned_total_portions !== $plan->confirmed_beneficiaries) {
            $issues[] = 'Total seluruh porsi tidak sama dengan total penerima terkonfirmasi.';
        }

        return array_values(array_unique($issues));
    }

    public function submit(FieldDistributionPlan $plan, User $actor, ?string $notes = null): array
    {
        if (! $actor->can('field_planning.submit')) {
            throw new DomainException('Anda tidak memiliki izin untuk mengaktifkan rencana distribusi.');
        }

        if (! app(SystemUnit::class)->owns($plan)) {
            throw new DomainException('Rencana distribusi bukan milik Unit SPPG aktif.');
        }

        $issues = $this->submissionIssues($plan);

        if ($issues !== []) {
            throw new DomainException(implode("\n", $issues));
        }

        if (! $plan->isEditable()) {
            throw new DomainException('Rencana tidak berada pada status yang dapat diajukan.');
        }

        return DB::transaction(function () use ($plan, $actor, $notes): array {
            $this->transitionInsideTransaction(
                $plan,
                FieldDistributionPlanStatus::Activated,
                $actor,
                $notes ?: 'Rencana diaktifkan',
                [
                    'submitted_by' => $actor->getKey(),
                    'submitted_at' => now(),
                    'activated_by' => $actor->getKey(),
                    'activated_at' => now(),
                    'approved_by' => null,
                    'approved_at' => null,
                    'review_notes' => null,
                ]
            );

            $plan->refresh();
            $distributionRuns = (int) $plan->planned_total_portions > 0
                ? app(FieldOperationalPlanGenerator::class)->generateDistributionRuns($plan, $actor)
                : collect();

            foreach ($distributionRuns as $run) {
                app(Mobile\OperationalNotificationService::class)->notifyPermissionAfterCommit(
                    unitId: (int) $plan->sppg_unit_id,
                    permission: 'distribution.update',
                    type: 'distribution_scheduled',
                    title: 'Pengiriman Dijadwalkan',
                    message: "Rute {$run->route_name} tersedia untuk tanggal {$plan->distribution_date?->format('d-m-Y')}.",
                    priority: 'info',
                    module: 'distribution',
                    referenceType: 'distribution_run',
                    referenceId: $run->getKey(),
                    moduleSlug: 'distribusi',
                    moduleLabel: 'Distribusi',
                    eventVersion: 'scheduled',
                    divisionCode: 'distribusi',
                );
            }

            app(Mobile\OperationalNotificationService::class)->notifyPermissionAfterCommit(
                unitId: (int) $plan->sppg_unit_id,
                permission: 'field_planning.update',
                type: 'field_plan_activated',
                title: 'Rencana Distribusi Aktif',
                message: "{$plan->plan_number} telah diaktifkan dengan {$distributionRuns->count()} rute.",
                priority: 'info',
                module: 'field_planning',
                referenceType: 'field_distribution_plan',
                referenceId: $plan->getKey(),
                moduleSlug: 'field-plans',
                moduleLabel: 'Rencana Distribusi',
                eventVersion: FieldDistributionPlanStatus::Activated->value,
                payload: ['field_plan_id' => (string) $plan->getKey()],
                screen: 'field-plans',
            );

            $documents = [
                // Pengolahan baru dibuat ketika divisi mencatat pengambilan bahan.
                // Pemorsian dibuat secara manual dari rencana aktif pada ruang kerjanya.
                'processing_batch' => null,
                'portioning_session' => null,
                'distribution_run' => $distributionRuns->pluck('run_number')->implode(', '),
                'distribution_runs' => $distributionRuns->pluck('run_number')->all(),
                'skipped' => array_values(array_filter([
                    'Batch Pengolahan menunggu pengambilan bahan oleh Divisi Pengolahan.',
                    'Sesi Pemorsian dibuat manual oleh Divisi Pemorsian dari rencana aktif.',
                    $distributionRuns->isNotEmpty()
                        ? null
                        : 'Seluruh tujuan tidak menerima pelayanan sehingga rute Distribusi tidak dibentuk.',
                ])),
            ];

            return [
                'operational_documents' => $documents,
            ];
        });
    }

    public function synchronize(FieldDistributionPlan $plan, User $actor): array
    {
        throw new DomainException('Sinkronisasi otomatis Pengolahan dan Pemorsian dinonaktifkan. Rute Distribusi dibentuk saat rencana diaktifkan.');
    }

    public function complete(FieldDistributionPlan $plan, User $actor, ?string $notes = null): void
    {
        $plan->refresh();
        if ($plan->status === FieldDistributionPlanStatus::Completed) {
            return;
        }
        if ($plan->status !== FieldDistributionPlanStatus::Activated) {
            throw new DomainException('Hanya rencana yang sudah diaktifkan yang dapat diselesaikan.');
        }

        $hasOpenDistributionRoute = $plan->distributionRuns()
            ->whereNotIn('state', [
                DistributionRunState::Returned->value,
                DistributionRunState::Cancelled->value,
            ])
            ->exists();

        if ($hasOpenDistributionRoute) {
            throw new DomainException('Rencana belum dapat diselesaikan karena masih ada rute Distribusi yang belum kembali ke SPPG.');
        }

        DB::transaction(function () use ($plan, $actor, $notes): void {
            $this->transitionInsideTransaction(
                $plan,
                FieldDistributionPlanStatus::Completed,
                $actor,
                $notes ?: 'Seluruh rute pengantaran makanan telah kembali ke SPPG.',
                ['completed_at' => now()],
            );
        });
    }

    private function transition(
        FieldDistributionPlan $plan,
        FieldDistributionPlanStatus $to,
        User $actor,
        ?string $notes,
        array $attributes = [],
    ): void {
        DB::transaction(fn () => $this->transitionInsideTransaction($plan, $to, $actor, $notes, $attributes));
    }

    private function transitionInsideTransaction(
        FieldDistributionPlan $plan,
        FieldDistributionPlanStatus $to,
        User $actor,
        ?string $notes,
        array $attributes = [],
    ): void {
        $plan->refresh();
        $from = $plan->status?->value;

        $plan->forceFill(array_merge($attributes, [
            'status' => $to,
            'updated_by' => $actor->getKey(),
        ]))->save();

        $plan->histories()->create([
            'from_status' => $from,
            'to_status' => $to->value,
            'actor_id' => $actor->getKey(),
            'actor_name_snapshot' => $actor->name,
            'notes' => $notes,
            'snapshot' => $this->snapshot($plan),
        ]);
    }

    private function snapshot(FieldDistributionPlan $plan): array
    {
        $plan->load('destinations.recipientGroups');

        return [
            'plan_number' => $plan->plan_number,
            'distribution_date' => $plan->distribution_date?->toDateString(),
            'menu_name' => $plan->menu_name_snapshot,
            'confirmed_beneficiaries' => $plan->confirmed_beneficiaries,
            'planned_total_portions' => $plan->planned_total_portions,
            'destination_count' => $plan->destination_count,
            'destinations' => $plan->destinations->map(fn ($destination): array => [
                'name' => $destination->destination_name_snapshot,
                'confirmed' => $destination->confirmed_beneficiaries,
                'small' => $destination->small_portions,
                'large' => $destination->large_portions,
                'route' => $destination->route_name,
                'recipient_groups' => $destination->recipientGroups->map(fn ($group): array => [
                    'name' => $group->beneficiary_category_name_snapshot,
                    'menu_audience' => $group->menu_audience,
                    'portion_size' => $group->portion_size,
                    'registered' => $group->registered_beneficiaries,
                    'confirmed' => $group->confirmed_beneficiaries,
                    'small' => $group->small_portions,
                    'large' => $group->large_portions,
                ])->all(),
            ])->all(),
        ];
    }
}
